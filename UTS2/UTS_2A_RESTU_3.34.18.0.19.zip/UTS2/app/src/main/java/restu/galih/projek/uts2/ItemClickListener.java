package restu.galih.projek.uts2;

import android.view.View;

public interface ItemClickListener {

    void onItemClickListener(View v, int position);
}
